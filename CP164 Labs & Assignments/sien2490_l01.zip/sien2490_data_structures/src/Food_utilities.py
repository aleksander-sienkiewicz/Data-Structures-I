"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aleksander Sienkiewicz
ID:      210222490
Email:   sien2490@mylaurier.ca
__updated__ = "2022-01-12"
-------------------------------------------------------
"""
# Imports

# Constants
from Food import Food
from pickle import TRUE, FALSE
def get_food():
    """
    ----
    """
    name= input("Enter Name: ")
    print("Enter Origin")
    print(Food.origins())
    origin=int(input("Enter origin: "))
    vegi = input("Vegeratrian or not (Y/N): ")
    if vegi == "Y":
        is_vegitarian=True
    else:
        is_vegitarian = False
    calories = int(input("Enter Calories: "))
    food = Food(name, origin, is_vegitarian, calories)
    return food

def read_food(line):
    """
    ---
    """
    line = line.split("|")
    name=line[0]
    origin=int(line[1])
    if line[2]==True:
        is_vegetarian=True
    else:
        is_vegetarian=False
    calories=int(line[3])
        
    food = Food(name,origin,is_vegetarian,calories)
    return food
def read_foods(file_variable):
    """
    ---
    """
    line=file_variable.readline()
    foods=[]
    while line !='':
        line.strip()
        foods.append(read_food(line))
        line=file_variable.line()
    
    return foods
def write_foods(file_name,foods):
    for food in foods: 
        file_name.write("{}|{}|{}|{}\n".format(
            food.name,food.origin,food.is_vegetarian,food.calories))
    return
def get_vegetarian(foods):
    """
    --
    """
    vegan=[]
    #create a list for it
    for food in foods:
        if food.is_vegetarian:
            vegan.append(food)        
    return vegan